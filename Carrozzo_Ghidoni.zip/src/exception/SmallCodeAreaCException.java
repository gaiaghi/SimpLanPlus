package exception;

public class SmallCodeAreaCException extends Exception{

	public SmallCodeAreaCException(String message) {
		super(message);
	}

}