package exception;

public class TypeErrorException extends Exception {

	public TypeErrorException(String message) {
		super(message);
	}

}
