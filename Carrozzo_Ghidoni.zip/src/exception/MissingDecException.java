package exception;

public class MissingDecException extends Exception{
	
	public MissingDecException(String message) {
		super(message);
	}

}
