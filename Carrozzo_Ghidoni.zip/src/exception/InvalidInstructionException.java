package exception;

public class InvalidInstructionException extends Exception {

	public InvalidInstructionException(String message) {
		super(message);
	}

}
