package exception;

public class MultipleDecException extends Exception{
	
	public MultipleDecException(String message) {
		super(message);
	}

}
