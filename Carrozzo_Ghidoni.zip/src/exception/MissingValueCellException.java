package exception;

public class MissingValueCellException extends Exception{

	public MissingValueCellException(String message) {
		super(message);
	}

}
