package exception;

public class AccessToFreeMemoryCellException extends Exception{

	public AccessToFreeMemoryCellException(String message) {
		super(message);
	}

}
