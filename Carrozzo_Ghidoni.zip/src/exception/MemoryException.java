package exception;

public class MemoryException extends Exception{

	public MemoryException(String message) {
		super(message);
	}

}
